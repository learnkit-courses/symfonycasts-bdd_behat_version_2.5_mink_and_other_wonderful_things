BDD, Behat, Mink and other Wonderful Things
===========================================

Well hi there! This repository holds the code and script
for the Behat PHP course on KnpUniversity.

Have fun!
