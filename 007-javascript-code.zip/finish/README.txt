BDD, Behat, Mink and other Wonderful Things
===========================================

Hi there! Enclosed are a bunch of files that represent beginning and
ending results of the BDD/Behat screencast!

Here's what we have:

* behat        The end result of the project created in chapter 1
* behat-ls     The end result of the project created in chapters 2-7
* behat-silex  The start and end result of the Silex project used in 8-10

For more details, look inside each directory!

<3 Bye!
