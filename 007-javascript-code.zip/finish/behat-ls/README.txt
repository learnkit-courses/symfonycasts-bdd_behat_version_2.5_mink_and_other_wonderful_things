Behat-ls
========

This directory contains the end-result of the project built in chapters 2 - 7.
To execute things:

1) php composer.phar install
2) php bin/behat
