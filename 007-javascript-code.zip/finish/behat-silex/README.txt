Behat-silex
===========

This directory contains the start and end version of the Silex project
that we tested on in chapters 8-10.

1) php composer.phar install
2) Customize the behat.yml file (and setup a virtual-host if needed)
3) Setup the database - "chmod -R 777 data"
4) Initialize the database - surf in your browser to http://store.l/_db/rebuild.json
5) php bin/behat
