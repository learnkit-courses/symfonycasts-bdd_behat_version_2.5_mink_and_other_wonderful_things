Behat
=====

This directory contains the end-result of the project built in chapter 1.
To execute things:

1) php composer.phar install
2) php bin/behat
